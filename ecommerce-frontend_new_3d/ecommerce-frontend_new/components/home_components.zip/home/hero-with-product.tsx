"use client"

import { useGetProductsQuery } from "@/store/services/productApi"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Truck, Shield, Clock, Sparkles, Star } from "lucide-react"
import Simple3DViewer from '@/components/product/simple-3d-viewer'
import { getBackendMediaUrl } from '@/utils/product-utils'

export default function HeroWithProduct() {
  // Fetch products - no authentication required, no specific filters
  const { data: products, isLoading: productsLoading, error } = useGetProductsQuery({ 
    page_size: 10
  })

  // Find a product with a 3D model
  const featuredProduct = products?.find((product) => {
    return (product.media && product.media.some((m) => m.file_type === 'model'))
  }) || products?.[0]
  const modelMedia = featuredProduct?.media?.find((m) => m.file_type === 'model')

  const isLoading = productsLoading

  // Debug logging
  console.log("Hero Debug:", { 
    productsCount: products?.length, 
    featuredProduct, 
    isLoading, 
    error,
    hasImageUrls: featuredProduct?.image_urls?.length 
  })

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-purple-600 via-violet-600 to-indigo-700">
      <div className="absolute inset-0 bg-grid-white/[0.05] [mask-image:linear-gradient(0deg,#fff,rgba(255,255,255,0.7))]"></div>

      {/* Enhanced decorative blobs */}
      <div className="absolute top-20 right-[10%] w-96 h-96 bg-pink-500/40 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 left-[5%] w-[500px] h-[500px] bg-blue-500/30 rounded-full blur-3xl animate-pulse delay-1000"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-500"></div>

      <div className="container mx-auto px-4 py-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-28 items-center">
          <div className="text-center lg:text-left">
            <Badge className="mb-8 py-3 px-6 text-lg bg-white/20 text-white hover:bg-white/30 backdrop-blur-md border border-white/30">
              <Sparkles className="h-5 w-5 mr-2" /> Premium Collection 2025
            </Badge>
            <h1 className="text-6xl md:text-7xl lg:text-8xl font-bold text-white mb-8 leading-tight">
              Discover{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-orange-300 animate-pulse">
                Amazing
              </span>{" "}
              Products
            </h1>
            <p className="text-2xl md:text-3xl text-purple-100 mb-12 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              {featuredProduct
                ? `Experience our ${featuredProduct.name} in stunning detail`
                : "Shop the latest trends with our easy-to-use platform and secure checkout."}
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start mb-12">
              <Link href="/products">
                <Button
                  size="lg"
                  className="bg-white text-purple-700 hover:bg-white/90 w-full sm:w-auto text-xl h-16 px-10 rounded-2xl shadow-2xl hover:shadow-3xl transition-all transform hover:scale-105"
                >
                  Shop Now
                  <ArrowRight className="ml-3 h-6 w-6" />
                </Button>
              </Link>
              {featuredProduct && (
                <Link href={`/products/${featuredProduct.id}`}>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-3 border-white text-white hover:bg-white/10 w-full sm:w-auto text-xl h-16 px-10 rounded-2xl backdrop-blur-sm transform hover:scale-105 transition-all"
                  >
                    View Product
                  </Button>
                </Link>
              )}
            </div>

            {/* Product rating if available */}
            {featuredProduct?.average_rating && (
              <div className="mt-8 flex items-center justify-center lg:justify-start">
                <div className="flex items-center backdrop-blur-md bg-white/15 px-4 py-2 rounded-full">
                  <div className="flex items-center mr-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < Math.floor(Number(featuredProduct.average_rating))
                            ? "text-yellow-400 fill-yellow-400"
                            : "text-white/50"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-white font-medium">
                    {Number(featuredProduct.average_rating).toFixed(1)} ({featuredProduct.review_count || 0} reviews)
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Enhanced Glass Container for Product Display */}
          <div className="relative flex justify-center lg:justify-end items-center min-h-[700px]">
            {/* Outer glow effect */}
            <div className="absolute -inset-8 bg-gradient-to-r from-pink-500/60 via-purple-500/60 to-blue-500/60 rounded-3xl blur-3xl opacity-70 animate-pulse"></div>
            
            {/* Main glass container */}
            <div className="relative w-full max-w-2xl w-[600px] h-[700px] rounded-3xl overflow-hidden shadow-2xl">
              {/* Glass effect layers */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/25 to-white/10 backdrop-blur-2xl border border-white/40 rounded-3xl"></div>
              <div className="absolute inset-0 bg-gradient-to-br from-white/15 to-transparent rounded-3xl"></div>
              
              {/* Inner content container */}
              <div className="relative h-full w-full p-8 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl overflow-hidden bg-white/10 backdrop-blur-sm border border-white/30">
                  {!isLoading && modelMedia ? (
                    <Simple3DViewer
                      modelUrl={getBackendMediaUrl(modelMedia.url)}
                      productName={featuredProduct?.name || 'Product'}
                      isDefault={false}
                      width={400}
                      height={400}
                    />
                  ) : (
                    // Fallback to default 3D model
                    <Simple3DViewer
                      modelUrl={getBackendMediaUrl('/assets/3d/shirt.glb')}
                      productName={featuredProduct?.name || 'Default Model'}
                      isDefault={true}
                      width={400}
                      height={400}
                    />
                  )}
                </div>
              </div>

              {/* Enhanced floating accent elements */}
              <div className="absolute top-6 right-6 w-4 h-4 bg-white/40 rounded-full backdrop-blur-sm animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-3 h-3 bg-white/30 rounded-full backdrop-blur-sm animate-pulse delay-500"></div>
              <div className="absolute top-1/2 -right-3 w-2 h-2 bg-white/50 rounded-full backdrop-blur-sm animate-pulse delay-1000"></div>
              <div className="absolute top-1/3 -left-2 w-1 h-1 bg-white/60 rounded-full backdrop-blur-sm animate-pulse delay-1500"></div>
            </div>

            {/* Additional decorative elements */}
            <div className="absolute -top-8 -left-8 w-16 h-16 bg-gradient-to-br from-pink-400/40 to-purple-400/40 rounded-full blur-sm animate-pulse"></div>
            <div className="absolute -bottom-10 -right-10 w-20 h-20 bg-gradient-to-br from-blue-400/30 to-cyan-400/30 rounded-full blur-sm animate-pulse delay-1000"></div>
          </div>
        </div>
      </div>

      {/* Enhanced wave divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="w-full">
          <path
            fill="#ffffff"
            fillOpacity="1"
            d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,149.3C960,160,1056,160,1152,138.7C1248,117,1344,75,1392,53.3L1440,32L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>
    </section>
  )
}
