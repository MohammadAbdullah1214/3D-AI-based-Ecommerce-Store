"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { useGetCartQuery, useClearCartMutation } from "@/store/services/cartApi"
import { useCheckoutMutation } from "@/store/services/orderApi"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { ShoppingBag, CreditCard, Loader2 } from "lucide-react"
import Link from "next/link"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"

// Form schema with validation
const checkoutFormSchema = z.object({
  shipping_address: z.string().min(10, {
    message: "Shipping address must be at least 10 characters.",
  }),
  billing_address: z.string().min(10, {
    message: "Billing address must be at least 10 characters.",
  }),
  payment_method: z.enum(["credit_card", "paypal", "bank_transfer"], {
    required_error: "Please select a payment method.",
  }),
  notes: z.string().optional(),
})

type CheckoutFormValues = z.infer<typeof checkoutFormSchema>

export default function CheckoutPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Get cart data
  const { data: cart, isLoading: isLoadingCart, error: cartError } = useGetCartQuery()
  const [clearCart] = useClearCartMutation()
  const [checkout] = useCheckoutMutation()

  // Initialize form
  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutFormSchema),
    defaultValues: {
      shipping_address: "",
      billing_address: "",
      payment_method: "credit_card",
      notes: "",
    },
  })

  // Handle form submission
  const onSubmit = async (values: CheckoutFormValues) => {
    if (!cart || cart.items.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Your cart is empty. Please add items before checkout.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Call the checkout API
      const result = await checkout(values).unwrap()

      // Clear the cart after successful checkout
      await clearCart()

      toast({
        title: "Order Placed Successfully",
        description: "Your order has been placed and is being processed.",
      })

      // Redirect to success page
      router.push("/checkout/success")
    } catch (error) {
      console.error("Checkout error:", error)
      toast({
        title: "Checkout Failed",
        description: "There was a problem processing your order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Handle empty cart or loading states
  if (isLoadingCart) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12 flex justify-center items-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  if (cartError) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="max-w-md mx-auto text-center">
            <h2 className="text-2xl font-bold mb-4">Error Loading Cart</h2>
            <p className="mb-6">There was a problem loading your cart. Please try again later.</p>
            <Link href="/cart">
              <Button>Return to Cart</Button>
            </Link>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  if (!cart || cart.items.length === 0) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="max-w-md mx-auto text-center">
            <ShoppingBag className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h2 className="text-2xl font-bold mb-4">Your Cart is Empty</h2>
            <p className="mb-6">Add some items to your cart before proceeding to checkout.</p>
            <Link href="/products">
              <Button>Browse Products</Button>
            </Link>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  return (
    <HeaderWrapper>
      <div className="container mx-auto py-12">
        <h1 className="text-3xl font-bold mb-8 text-center">Checkout</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Checkout Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Shipping & Payment</CardTitle>
                <CardDescription>Complete your order by providing your shipping and payment details.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="shipping_address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Shipping Address*</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Enter your full shipping address"
                              {...field}
                              className="min-h-[100px]"
                            />
                          </FormControl>
                          <FormDescription>
                            Please provide your complete address including street, city, and country.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="billing_address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Billing Address*</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Enter your full billing address"
                              {...field}
                              className="min-h-[100px]"
                            />
                          </FormControl>
                          <FormDescription>
                            Please provide your complete billing address including street, city, and country.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="payment_method"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Payment Method*</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="credit_card" />
                                </FormControl>
                                <FormLabel className="font-normal">Credit Card</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="paypal" />
                                </FormControl>
                                <FormLabel className="font-normal">PayPal</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="bank_transfer" />
                                </FormControl>
                                <FormLabel className="font-normal">Bank Transfer</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Order Notes (Optional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Add any special instructions or notes for your order"
                              {...field}
                              className="min-h-[80px]"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="pt-4">
                      <Button type="submit" className="w-full" disabled={isSubmitting}>
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <CreditCard className="mr-2 h-4 w-4" />
                            Place Order
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Review your order before completing checkout.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Cart Items */}
                  <div className="space-y-3">
                    {cart.items.map((item) => (
                      <div key={item.id} className="flex justify-between items-center py-2 border-b">
                        <div className="flex items-center">
                          <div className="font-medium">{item.product_details?.name || "Product"}</div>
                          <div className="text-sm text-gray-500 ml-2">x{item.quantity}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Order Totals */}
                  <div className="flex justify-between font-bold text-lg">
                    <span>Grand Total</span>
                    <span>${cart.shipping_info?.grand_total?.toFixed(2) ?? "0.00"}</span>
                  </div>

                  <div className="text-sm text-gray-500 mt-4">
                    <p>All prices are in USD.</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Link href="/cart">
                  <Button variant="outline">
                    <ShoppingBag className="mr-2 h-4 w-4" />
                    Back to Cart
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
