"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { useGetProductQuery } from "@/store/services/productApi"
import { useGetAllMediaQuery } from "@/store/services/mediaApi"
import { useAddToCartMutation } from "@/store/services/cartApi"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Star,
  Minus,
  Plus,
  ShoppingCart,
  Truck,
  Clock,
  Shield,
  Info,
  CheckCircle,
  CuboidIcon as Cube,
  Play,
  Heart,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import Simple3DViewer from "@/components/product/simple-3d-viewer"
import { ProductGallery } from "@/components/product/product-gallery"
import { getProductPrice, getProductStock, getBackendMediaUrl, getMediaUrl } from "@/utils/product-utils"
import { useSelector } from 'react-redux'
import { useRouter } from 'next/navigation'
import { useAddItemMutation, useCheckProductQuery, useRemoveItemMutation } from '@/store/services/wishlistApi'

export default function ProductDetailPage() {
  const params = useParams()
  const productId = typeof params?.id === "string" ? params.id : Array.isArray(params?.id) ? params.id[0] : "0"

  const { toast } = useToast()

  const { data: product, isLoading, error } = useGetProductQuery(Number(productId))
  const { data: allMedia = [], isLoading: mediaLoading } = useGetAllMediaQuery()
  const [addToCart, { isLoading: isAddingToCart }] = useAddToCartMutation()
  const [quantity, setQuantity] = useState(1)
  const [selectedVariant, setSelectedVariant] = useState(0)

  // Prefer product.media if available, otherwise fallback to allMedia
  const productMedia = product?.media && product.media.length > 0
    ? product.media
    : allMedia.filter((media) => media.product === Number(productId));

  // Only use the images array and filter by file_type
  const images = product?.images ? product.images.filter(m => m.file_type === 'image') : [];
  const videos = product?.images ? product.images.filter(m => m.file_type === 'video') : [];
  const models = product?.images ? product.images.filter(m => m.file_type === 'model' || m.file_type === 'model_3d') : [];

  // Helper to get the correct image URL
  const galleryMedia = images.map(img => ({
    ...img,
    url: getMediaUrl(img) || img.image_url || img.file_url || img.image || img.file || '',
    file_type: img.file_type || 'image',
  }))
    .concat(videos.map(vid => ({
      ...vid,
      url: getMediaUrl(vid) || vid.image_url || vid.file_url || vid.image || vid.file || '',
      file_type: vid.file_type || 'video',
    })))
    .filter(m => typeof m.url === 'string' && m.url && typeof m.file_type === 'string' && m.file_type);

  // Use image_urls for images if present, otherwise use galleryImagesAndVideos
  const imageUrls = product?.image_urls && product.image_urls.length > 0
    ? product.image_urls
    : images.map(m => getMediaUrl(m) || m.image_url || m.file_url || m.image || m.file || '');
  const imageIds = product?.image_ids && product.image_ids.length > 0
    ? product.image_ids
    : images.map((m, idx) => m.id ?? idx);
  const galleryImages = imageUrls.length > 0
    ? imageUrls.map((url, idx) => ({
        id: imageIds[idx] ?? idx,
        url: url || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(product?.name || 'Product')}`,
        image_url: url || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(product?.name || 'Product')}`,
        file: url || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(product?.name || 'Product')}`,
        file_url: url || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(product?.name || 'Product')}`,
        file_type: "image" as const,
        is_primary: idx === 0,
        sort_order: idx + 1,
      }))
    : [];

  // Only pass images and videos (not 3D models) to the gallery
  const galleryOnlyMedia = images.concat(videos);

  const incrementQuantity = () => setQuantity((prev) => prev + 1)
  const decrementQuantity = () => setQuantity((prev) => (prev > 1 ? prev - 1 : 1))

  const { isAuthenticated, user } = useSelector((state: any) => state.auth)
  const router = useRouter()
  const [addItem, { isLoading: isAddingWishlist }] = useAddItemMutation()
  const [removeItem, { isLoading: isRemovingWishlist }] = useRemoveItemMutation()
  const { data: isWishlisted, refetch: refetchWishlist } = useCheckProductQuery(
    { product_id: product?.id ?? 0 },
    { skip: !product?.id }
  )
  const [wishlistError, setWishlistError] = useState<string | null>(null)

  const isSeller = user && product && user.id === (product.seller_id ?? 0)

  const handleAddToCart = async () => {
    if (!isAuthenticated) {
      router.push(`/login?next=/products/${productId}`)
      return
    }
    if (isSeller) {
      toast({
        title: 'Not allowed',
        description: 'You cannot add your own product to cart.',
        variant: 'destructive',
      })
      return
    }
    if (!product) return

    try {
      console.log("Adding product to cart:", {
        product_id: Number(product.id),
        quantity: quantity,
      })

      const result = await addToCart({
        product_id: Number(product.id ?? 0),
        quantity: quantity,
      }).unwrap()

      console.log("Add to cart success:", result)

      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart.`,
        variant: "default",
      })
    } catch (error) {
      console.error("Add to cart error:", error)

      let errorMessage = "Failed to add product to cart. Please try again."

      if (error && typeof error === "object") {
        if ("data" in error && error.data && typeof error.data === "object") {
          if ("detail" in error.data) {
            errorMessage = String(error.data.detail)
          } else if ("error" in error.data) {
            errorMessage = String(error.data.error)
          }
        } else if ("error" in error) {
          errorMessage = String(error.error)
        }
      } else if (typeof error === "string") {
        errorMessage = error
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      })
    }
  }

  const handleAddToWishlist = async () => {
    setWishlistError(null)
    if (!isAuthenticated) {
      router.push(`/login?next=/products/${productId}`)
      return
    }
    if (isSeller) {
      setWishlistError('You cannot wishlist your own product.')
      return
    }
    if (!product) return
    try {
      if (isWishlisted?.in_wishlist) {
        await removeItem({ product_id: product.id })
      } else {
        await addItem({ product_id: product.id })
      }
      refetchWishlist()
    } catch (err) {
      setWishlistError('Wishlist action failed')
    }
  }

  // Add guards for possibly undefined product before all usages
  if (isLoading) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  if (error || !product) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Product not found</h2>
            <p className="mt-4">The product you are looking for does not exist or has been removed.</p>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  // Mock variants for demonstration
  const productPrice = getProductPrice(product) ?? 0;
  const variants = [
    { name: "Regular", price: productPrice },
    { name: "Premium", price: productPrice * 1.1 },
    { name: "Deluxe", price: productPrice * 1.2 },
  ]

  const productStock = getProductStock(product) ?? 0;
  const categoryName = product.category_details?.name || product.category?.name || product.category_name || "Unknown";
  const sellerName = product.seller_name || product.seller_username || "Unknown";

  return (
    <HeaderWrapper>
      <div className="container mx-auto py-8">
        {/* Product header with name and category */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-4 rounded-lg mb-6">
          <h1 className="text-xl font-bold uppercase">{product.name}</h1>
          <p className="text-sm opacity-80">Premium {categoryName}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left column - Product media */}
          <div className="lg:col-span-5">
            <div className="sticky top-24">
              <div className="bg-white rounded-lg shadow-md p-4 mb-4">
                {/* Product Gallery with Carousel */}
                {galleryMedia.length > 0 ? (
                  <ProductGallery
                    media={galleryMedia}
                    productName={product.name}
                  />
                ) : (
                  <div className="aspect-square flex items-center justify-center bg-gray-100 rounded-lg mb-4">
                    <span className="text-gray-400">No images available for this product.</span>
                  </div>
                )}

                {/* 3D Model Gallery */}
                {models.length > 0 ? (
                  <div className="mt-6">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Cube className="h-4 w-4" />
                      3D Model View
                    </h3>
                    {models.map((model, idx) => (
                      <Simple3DViewer
                        key={model.id || idx}
                        modelUrl={getBackendMediaUrl(model.file || model.url)}
                        productName={product.name}
                        isDefault={true}
                        width={500}
                        height={400}
                        showControls={true}
                        showARButton={true}
                        className="mb-4"
                      />
                    ))}
                  </div>
                ) : (
                  <div className="mt-6 text-gray-400">No 3D model available for this product.</div>
                )}

                {/* Video Gallery */}
                {videos.length > 0 && (
                  <div className="space-y-4 mt-4">
                    <h3 className="font-semibold flex items-center gap-2">
                      <Play className="h-4 w-4" />
                      Product Videos
                    </h3>
                    <div className="grid grid-cols-1 gap-2">
                      {videos.slice(0, 2).map((video, index) => (
                        <div key={index} className="relative aspect-video overflow-hidden rounded-md border">
                          <video
                            src={video.file}
                            controls
                            className="w-full h-full object-cover"
                            poster="/placeholder.svg?height=200&width=300"
                          >
                            Your browser does not support the video tag.
                          </video>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md p-4">
                <h3 className="font-semibold mb-2">About this product</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Premium quality {categoryName} with exceptional features</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Carefully selected and processed for the best experience</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Sourced from the finest suppliers to ensure consistent quality</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Perfect for everyday use and special occasions</span>
                  </li>

                  {/* Show media type badges if available */}
                  <div className="flex flex-wrap gap-2 mt-4">
                    {models.length > 0 && (
                      <Badge className="flex items-center gap-1 bg-blue-100 text-blue-800 hover:bg-blue-200">
                        <Cube className="h-3 w-3" />
                        3D View Available
                      </Badge>
                    )}
                    {videos.length > 0 && (
                      <Badge className="flex items-center gap-1 bg-green-100 text-green-800 hover:bg-green-200">
                        <Play className="h-3 w-3" />
                        Video Available
                      </Badge>
                    )}
                    {galleryImages.length > 0 && (
                      <Badge className="flex items-center gap-1 bg-purple-100 text-purple-800 hover:bg-purple-200">
                        📷 {images.length} Images Available
                      </Badge>
                    )}
                  </div>
                </ul>
              </div>
            </div>
          </div>

          {/* Right column - Product info and purchase options */}
          <div className="lg:col-span-7">
            {/* Ratings */}
            <div className="flex items-center mb-4">
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-4 w-4 ${
                      star <= Math.round(Number(product.average_rating) || 0)
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="ml-2 text-sm text-gray-600">
                {Number(product.average_rating || 0).toFixed(1)} ({product.review_count || 0} reviews)
              </span>
            </div>

            {/* Variants */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {variants.map((variant, index) => (
                <Card
                  key={index}
                  className={`cursor-pointer transition-all ${selectedVariant === index ? "ring-2 ring-blue-500" : "hover:shadow-md"}`}
                  onClick={() => setSelectedVariant(index)}
                >
                  <CardContent className="p-4 text-center">
                    <p className="font-medium">{variant.name}</p>
                    <p className="text-sm text-gray-500">${variant.price.toFixed(2)}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Price */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <div className="flex items-baseline">
                <span className="text-3xl font-bold text-blue-600">${variants[selectedVariant]?.price.toFixed(2)}</span>
                {product.discount_price && Number(product.discount_price) > 0 && (
                  <span className="ml-2 text-lg text-gray-500 line-through">
                    ${typeof product.price === "number" ? product.price.toFixed(2) : product.price}
                  </span>
                )}
                {product.discount_price && Number(product.discount_price) > 0 && (
                  <Badge className="ml-2 bg-red-500">
                    Save $
                    {(
                      (typeof product.price === "number" ? product.price : Number.parseFloat(String(product.price))) -
                      (typeof product.discount_price === "number"
                        ? product.discount_price
                        : Number.parseFloat(String(product.discount_price)))
                    ).toFixed(2)}
                  </Badge>
                )}
              </div>
            </div>

            {/* Stock and delivery */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              {productStock > 0 ? (
                <div className="flex items-center text-green-600 mb-4">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span className="font-medium">In Stock</span>
                </div>
              ) : (
                <div className="flex items-center text-red-600 mb-4">
                  <Info className="h-5 w-5 mr-2" />
                  <span className="font-medium">Out of Stock</span>
                </div>
              )}

              <div className="space-y-2 text-sm">
                <div className="flex items-center">
                  <Truck className="h-4 w-4 mr-2 text-gray-500" />
                  <span>Want it tomorrow? Order in the next 4 hours 23 minutes.</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  <span>FREE delivery by tomorrow.</span>
                </div>
                <div className="flex items-center">
                  <Shield className="h-4 w-4 mr-2 text-gray-500" />
                  <span>Secure transaction. Return policy available.</span>
                </div>
              </div>
            </div>

            {/* Quantity and add to cart */}
            {productStock > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-medium">Quantity:</span>
                  <div className="flex items-center border rounded-md">
                    <Button variant="ghost" size="icon" onClick={decrementQuantity} disabled={quantity <= 1}>
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-12 text-center">{quantity}</span>
                    <Button variant="ghost" size="icon" onClick={incrementQuantity}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <Button
                    className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-medium"
                    onClick={handleAddToCart}
                    disabled={isAddingToCart || isSeller}
                  >
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    {isSeller ? 'Your Product' : 'Add to Cart'}
                  </Button>
                  {isSeller && (
                    <div className="text-red-600 text-xs mt-1">You cannot add your own product to cart.</div>
                  )}
                </div>
              </div>
            )}

            {/* Wishlist button - always visible */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <Button
                variant={isWishlisted?.in_wishlist ? 'default' : 'outline'}
                className={`w-full ${isWishlisted?.in_wishlist ? 'text-pink-500 border-pink-500' : ''}`}
                onClick={handleAddToWishlist}
                disabled={isAddingWishlist || isRemovingWishlist || isSeller}
              >
                <Heart className="mr-2 h-4 w-4" fill={isWishlisted?.in_wishlist ? '#ec4899' : 'none'} />
                {isWishlisted?.in_wishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
              </Button>
              {wishlistError && <div className="text-red-600 text-xs mt-1">{wishlistError}</div>}
              {isSeller && (
                <div className="text-red-600 text-xs mt-1">You cannot wishlist your own product.</div>
              )}
            </div>

            {/* Variants Section (real data) */}
            {Array.isArray(product.variants) && product.variants.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 className="font-semibold mb-4">Available Variants</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product.variants.map((variant) => (
                    <div key={variant.id} className="border rounded p-4 flex flex-col gap-2">
                      <div className="font-medium">{variant.name || `Variant #${variant.id}`}</div>
                      <div className="text-sm text-gray-500">Price: ${variant.price_adjustment ? (Number(product.price) + Number(variant.price_adjustment)).toFixed(2) : Number(product.price).toFixed(2)}</div>
                      <div className="text-sm text-gray-500">Stock: {variant.stock_quantity ?? 0}</div>
                      {Array.isArray(variant.options) && variant.options.length > 0 && (
                        <div className="text-xs text-gray-400">Options: {variant.options.map(opt => opt.option_value || opt.value).join(", ")}</div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tabs for details */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <Tabs defaultValue="details">
                <TabsList className="w-full grid grid-cols-4 bg-gray-100">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                  <TabsTrigger value="questions">Questions</TabsTrigger>
                  <TabsTrigger value="shipping">Shipping</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="p-6">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-gray-50 p-3">
                        <span className="font-medium">Brand</span>
                      </div>
                      <div className="bg-gray-50 p-3">
                        <span>{sellerName}</span>
                      </div>

                      <div className="bg-gray-50 p-3">
                        <span className="font-medium">Category</span>
                      </div>
                      <div className="bg-gray-50 p-3">
                        <span>{categoryName}</span>
                      </div>

                      <div className="bg-gray-50 p-3">
                        <span className="font-medium">Stock</span>
                      </div>
                      <div className="bg-gray-50 p-3">
                        <span>{productStock} units available</span>
                      </div>

                      <div className="bg-gray-50 p-3">
                        <span className="font-medium">Shipping</span>
                      </div>
                      <div className="bg-gray-50 p-3">
                        <span>FREE delivery available</span>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="reviews" className="p-6">
                  <div className="space-y-4">
                    {Array.isArray(product.reviews) && product.reviews.length > 0 ? (
                      product.reviews.map((review) => (
                        <div key={review.id} className="border-b pb-4 mb-4">
                          <div className="flex items-center gap-2 mb-1">
                            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                            <span className="font-medium">{review.user_id || "User"}</span>
                            <span className="text-xs text-gray-500">{new Date(review.created_at).toLocaleDateString()}</span>
                          </div>
                          <div className="text-sm text-gray-700">{review.comment}</div>
                          <div className="text-xs text-gray-500 mt-1">Rating: {review.rating}/5</div>
                        </div>
                      ))
                    ) : (
                      <p>No reviews yet. Be the first to review this product!</p>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="questions" className="p-6">
                  <p>No questions yet. Ask a question about this product.</p>
                </TabsContent>

                <TabsContent value="shipping" className="p-6">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-gray-50 p-3">
                        <span className="font-medium">Domestic Shipping</span>
                      </div>
                      <div className="bg-gray-50 p-3">
                        <span>FREE delivery available</span>
                      </div>

                      <div className="bg-gray-50 p-3">
                        <span className="font-medium">Return Policy</span>
                      </div>
                      <div className="bg-gray-50 p-3">
                        <span>30-day return policy</span>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
