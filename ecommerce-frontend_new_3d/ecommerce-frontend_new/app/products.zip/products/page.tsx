"use client"

import { CardFooter } from "@/components/ui/card"
import { useState, useEffect, useMemo } from "react"
import { useSearchParams } from "next/navigation"
import { useGetProductsQuery, useGetCategoriesQuery } from "@/store/services/productApi"
import { useAddToCartMutation } from "@/store/services/cartApi"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Star, ChevronDown, Filter, SlidersHorizontal, ShoppingCart, CuboidIcon as Cube, Play, Heart } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { ProductImageCarousel } from "@/components/product/product-image-carousel"
import { getProductPrice, getProductStock, getBackendMediaUrl } from "@/utils/product-utils"
import { useSelector } from 'react-redux'
import { useRouter } from 'next/navigation'
import { useAddItemMutation } from "@/store/services/wishlistApi"
import type { Product } from '@/app/types';
import { useAuth } from '@/hooks/useAuth';

export default function ProductsPage() {
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { currentUser, isLoadingUser } = useAuth();
  const user = currentUser;
  const isAuthenticated = !!currentUser;
  const router = useRouter()

  // Get initial filter values from URL
  const initialCategory = searchParams?.get("category") || ""
  const initialMinPrice = searchParams?.get("min_price") ? Number(searchParams.get("min_price")) : 0
  const initialMaxPrice = searchParams?.get("max_price") ? Number(searchParams.get("max_price")) : 500
  const initialSearch = searchParams?.get("search") || ""

  // State for filters
  const [filters, setFilters] = useState({
    category: initialCategory,
    minPrice: initialMinPrice,
    maxPrice: initialMaxPrice,
    search: initialSearch,
    sortBy: "relevance",
  })

  // State for mobile filter visibility
  const [showMobileFilters, setShowMobileFilters] = useState(false)

  // Fetch products and categories
  const {
    data: products,
    isLoading: productsLoading,
    error: productsError,
  } = useGetProductsQuery({
    category: filters.category || undefined,
    min_price: filters.minPrice,
    max_price: filters.maxPrice,
    search: filters.search || undefined,
  })

  const { data: categories, isLoading: categoriesLoading } = useGetCategoriesQuery()
  const [addToCart] = useAddToCartMutation()
  const [addWishlistItem, { isLoading: isAddingWishlist }] = useAddItemMutation()

  // Quick add to cart function
  const handleQuickAddToCart = async (product: Product) => {
    if (!isAuthenticated) {
      router.push('/login')
      return
    }
    if (user && product && (user.id === product.seller_id || user.username === product.seller_username)) {
      toast({
        title: 'Not allowed',
        description: 'You cannot add your own product to cart.',
        variant: 'destructive',
      })
      return
    }
    try {
      await addToCart({
        product_id: Number(product.id),
        quantity: 1,
      }).unwrap()
      toast({
        title: "Added to cart",
        description: "Product has been added to your cart.",
      })
    } catch (error) {
      console.error("Add to cart error:", error)
      toast({
        title: "Error",
        description: "Failed to add product to cart.",
        variant: "destructive",
      })
    }
  }

  // Add this function
  const handleAddToWishlist = async (product: Product) => {
    if (!isAuthenticated) {
      router.push('/login')
      return
    }
    if (user && product && (user.id === product.seller_id || user.username === product.seller_username)) {
      toast({
        title: 'Not allowed',
        description: 'You cannot wishlist your own product.',
        variant: 'destructive',
      })
      return
    }
    try {
      await addWishlistItem({ product_id: Number(product.id) }).unwrap()
      toast({
        title: "Added to wishlist",
        description: "Product has been added to your wishlist.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add product to wishlist.",
        variant: "destructive",
      })
    }
  }

  // Age ranges for filtering
  const ageRanges = [
    { label: "Birth to 24 Months", value: "0-24m" },
    { label: "2 to 4 Years", value: "2-4y" },
    { label: "5 to 7 Years", value: "5-7y" },
    { label: "8 to 13 Years", value: "8-13y" },
    { label: "14 Years & Up", value: "14y+" },
  ]

  // Price ranges for quick selection
  const priceRanges = [
    { label: "Up to $5", value: [0, 5] },
    { label: "$5 to $10", value: [5, 10] },
    { label: "$10 to $15", value: [10, 15] },
    { label: "$15 to $25", value: [15, 25] },
    { label: "$25 & above", value: [25, 500] },
  ]

  // Brand options
  const brands = ["ShopHub", "Premium Brands", "Eco-Friendly", "Luxury Items", "Budget Friendly"]

  return (
    <HeaderWrapper>
      <div className="container mx-auto px-4 py-4">
        {/* Search results header */}
        <div className="mb-4">
          <h1 className="text-lg font-medium">
            {filters.search ? (
              <>
                {products?.length || 0} results for "{filters.search}"
              </>
            ) : (
              <>All Products</>
            )}
          </h1>
        </div>

        {/* Mobile filter button */}
        <div className="lg:hidden mb-4">
          <Button
            variant="outline"
            className="w-full flex items-center justify-between"
            onClick={() => setShowMobileFilters(!showMobileFilters)}
          >
            <span className="flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </span>
            <ChevronDown className={`h-4 w-4 transition-transform ${showMobileFilters ? "rotate-180" : ""}`} />
          </Button>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Filters sidebar */}
          <aside className={`w-full lg:w-64 shrink-0 ${showMobileFilters ? "block" : "hidden lg:block"}`}>
            <div className="bg-white rounded-lg shadow-sm p-4">
              {/* Customer Reviews */}
              <div className="mb-6">
                <h3 className="font-medium mb-2">Customer Reviews</h3>
                <div className="space-y-1">
                  {[5, 4, 3, 2, 1].map((rating) => (
                    <div key={rating} className="flex items-center">
                      <Checkbox id={`rating-${rating}`} className="mr-2" />
                      <Label htmlFor={`rating-${rating}`} className="flex items-center cursor-pointer">
                        {Array(5)
                          .fill(0)
                          .map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                            />
                          ))}
                        <span className="ml-1 text-sm text-gray-600">& Up</span>
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="my-4" />

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="font-medium mb-2">Price</h3>
                <div className="flex justify-between mb-2 text-sm">
                  <span>${filters.minPrice}</span>
                  <span>to</span>
                  <span>${filters.maxPrice}</span>
                </div>
                <Slider
                  defaultValue={[filters.minPrice, filters.maxPrice]}
                  max={500}
                  step={5}
                  onValueChange={(values) => {
                    setFilters({
                      ...filters,
                      minPrice: values[0],
                      maxPrice: values[1],
                    })
                  }}
                  className="mb-4"
                />

                <div className="space-y-1 text-sm">
                  {priceRanges.map((range, index) => (
                    <div key={index} className="flex items-center">
                      <button
                        className="text-left hover:text-blue-600 w-full"
                        onClick={() =>
                          setFilters({
                            ...filters,
                            minPrice: range.value[0],
                            maxPrice: range.value[1],
                          })
                        }
                      >
                        {range.label}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="my-4" />

              {/* Deals & Discounts */}
              <div className="mb-6">
                <h3 className="font-medium mb-2">Deals & Discounts</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox id="all-discounts" className="mr-2" />
                    <Label htmlFor="all-discounts" className="cursor-pointer">
                      All Discounts
                    </Label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="todays-deals" className="mr-2" />
                    <Label htmlFor="todays-deals" className="cursor-pointer">
                      Today's Deals
                    </Label>
                  </div>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Age Range */}
              <div className="mb-6">
                <h3 className="font-medium mb-2">Age Range</h3>
                <div className="space-y-2">
                  {ageRanges.map((range, index) => (
                    <div key={index} className="flex items-center">
                      <Checkbox id={`age-${range.value}`} className="mr-2" />
                      <Label htmlFor={`age-${range.value}`} className="cursor-pointer">
                        {range.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="my-4" />

              {/* Brands */}
              <div className="mb-6">
                <h3 className="font-medium mb-2">Brands</h3>
                <div className="space-y-2">
                  {brands.map((brand, index) => (
                    <div key={index} className="flex items-center">
                      <Checkbox id={`brand-${index}`} className="mr-2" />
                      <Label htmlFor={`brand-${index}`} className="cursor-pointer">
                        {brand}
                      </Label>
                    </div>
                  ))}
                  <button className="text-sm text-blue-600 hover:underline mt-2">See more</button>
                </div>
              </div>
            </div>
          </aside>

          {/* Product grid */}
          <main className="flex-1">
            {/* Sort options */}
            <div className="bg-white rounded-lg shadow-sm p-3 mb-4 flex justify-between items-center">
              <div className="flex items-center">
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                <span className="text-sm font-medium">Sort by:</span>
              </div>
              <select
                className="text-sm border-0 bg-transparent focus:ring-0"
                value={filters.sortBy}
                onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
              >
                <option value="relevance">Relevance</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Avg. Customer Review</option>
                <option value="newest">Newest Arrivals</option>
              </select>
            </div>

            {/* Featured section */}
            {!filters.search && !filters.category && (
              <div className="mb-6">
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-lg font-medium">Everything you need for everyday</h2>
                      <p className="text-sm text-gray-600">Shop top essentials from ShopHub Basics</p>
                    </div>
                    <Image src="/abstract-geometric-logo.png" alt="ShopHub Basics" width={120} height={40} />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[
                      { title: "For families", image: "/bustling-market-day.png" },
                      { title: "Toys", image: "/colorful-toy-collection.png" },
                      { title: "All Basics", image: "/everyday-essentials.png" },
                    ].map((item, index) => (
                      <div key={index} className="relative overflow-hidden rounded-lg">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.title}
                          width={300}
                          height={200}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                          <p className="text-center font-medium">{item.title}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Results heading */}
            <div className="mb-4">
              <h2 className="text-lg font-medium">Results</h2>
              <p className="text-sm text-gray-600">
                Check each product page for other buying options. Price and other details may vary based on product size
                and color.
              </p>
            </div>

            {/* Products grid */}
            {productsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {Array.from({ length: 8 }).map((_, index) => (
                  <Card key={index} className="animate-pulse">
                    <div className="aspect-square bg-gray-200"></div>
                    <CardContent className="p-4">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-6 bg-gray-200 rounded w-1/4 mt-4"></div>
                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                      <div className="h-10 bg-gray-200 rounded w-full"></div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : products && products.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {products.map((product) => {
                  const productPrice = getProductPrice(product)
                  const originalPrice =
                    typeof product.price === "number" ? product.price : Number.parseFloat(String(product.price))
                  const hasDiscount = productPrice < originalPrice

                  // Use image_urls for images
                  const imageUrls = product.image_urls || [];
                  const imageIds = product.image_ids || [];
                  const carouselImages = imageUrls.length > 0
                    ? imageUrls
                        .map((url, idx) => ({
                          id: (imageIds && imageIds[idx]) ?? idx,
                          url: url || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(product.name)}`,
                        }))
                        .filter(img => img && typeof img.url === 'string' && img.url.trim())
                    : [{
                        id: 0,
                        url: `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(product.name)}`,
                      }];

                  const has3dModel = product.has_3d_model || false;

                  return (
                    <Card key={Number(product.id)} className="group hover:shadow-lg transition-shadow">
                      <CardContent className="p-0">
                        <div className="relative">
                          {/* Product Image Carousel */}
                          <ProductImageCarousel
                            images={carouselImages}
                            productName={product.name}
                            onHover={true}
                            interval={1500}
                            showControls={false}
                          />

                          {/* Quick add to cart button */}
                          <Button
                            size="sm"
                            className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => {
                              e.preventDefault()
                              if (!isAuthenticated) {
                                router.push('/login')
                              } else {
                                handleQuickAddToCart(product)
                              }
                            }}
                          >
                            <ShoppingCart className="h-4 w-4" />
                          </Button>

                          {/* Media type badges */}
                          <div className="absolute top-2 left-2 flex flex-col gap-1">
                            {has3dModel && (
                              <Badge className="bg-blue-100 text-blue-800 text-xs">
                                <Cube className="h-3 w-3 mr-1" />
                                3D
                              </Badge>
                            )}
                            {imageUrls.length > 1 && (
                              <Badge className="bg-purple-100 text-purple-800 text-xs">
                                +{imageUrls.length - 1}
                              </Badge>
                            )}
                          </div>

                          {/* Add to wishlist button */}
                          <Button
                            size="sm"
                            variant="ghost"
                            className="absolute top-2 right-2 z-10 p-1 rounded-full bg-white/80 hover:bg-pink-100 border border-gray-200 text-gray-400"
                            onClick={(e) => {
                              e.preventDefault()
                              handleAddToWishlist(product)
                            }}
                            aria-label="Add to wishlist"
                            disabled={isAddingWishlist}
                          >
                            <Heart className="w-5 h-5" />
                          </Button>
                        </div>
                      </CardContent>

                      <CardContent className="p-4">
                        <Link href={`/products/${Number(product.id)}`} className="block">
                          <h3 className="font-medium text-sm line-clamp-2 mb-1 hover:text-blue-600">{product.name}</h3>
                        </Link>

                        <div className="flex items-center mb-1">
                          <div className="flex items-center">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-3 w-3 ${
                                  star <= Math.round(Number(product.average_rating) || 0)
                                    ? "text-yellow-400 fill-yellow-400"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="ml-1 text-xs text-gray-600">({product.review_count || 0})</span>
                        </div>

                        <div className="mt-2">
                          <div className="flex items-baseline">
                            <span className="text-lg font-bold">${productPrice.toFixed(2)}</span>
                            {hasDiscount && (
                              <span className="ml-2 text-sm text-gray-500 line-through">
                                ${originalPrice.toFixed(2)}
                              </span>
                            )}
                          </div>

                          <div className="text-xs text-gray-600 mt-1">
                            {product.stock ?? 0 > 0 ? (
                              <span>In stock</span>
                            ) : (
                              <span className="text-red-600">Out of stock</span>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                <h3 className="text-xl font-medium mb-4">No products found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your filters or search criteria.</p>
                <Button
                  onClick={() =>
                    setFilters({
                      category: "",
                      minPrice: 0,
                      maxPrice: 500,
                      search: "",
                      sortBy: "relevance",
                    })
                  }
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </main>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
