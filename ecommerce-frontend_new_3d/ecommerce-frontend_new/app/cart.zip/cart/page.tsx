"use client"

import { useGetCartQuery } from "@/store/services/cartApi"
import { Button } from "@/components/ui/button"
import { ShoppingCart, ArrowLeft } from "lucide-react"
import Link from "next/link"
import CartItemComponent from "@/components/cart/cart-item"
import CartSummary from "@/components/cart/cart-summary"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { useSelector } from 'react-redux'
import { useRouter } from 'next/navigation'

export default function CartPage() {
  const { isAuthenticated } = useSelector((state: any) => state.auth)
  const router = useRouter()
  const { data: cart, isLoading, error } = useGetCartQuery()

  if (!isAuthenticated) {
    if (typeof window !== 'undefined') {
      router.push('/login?next=/cart')
    }
    return null
  }

  if (isLoading) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  if (error) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Error loading cart</h2>
            <p className="mt-4">There was a problem loading your cart. Please try again later.</p>
            <Link href="/products">
              <Button className="mt-6">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Continue Shopping
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  if (!cart || cart.items.length === 0) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <div className="text-center">
            <ShoppingCart className="h-16 w-16 mx-auto text-gray-400" />
            <h2 className="text-2xl font-bold mt-4">Your cart is empty</h2>
            <p className="mt-2 text-gray-600">Looks like you haven't added any products to your cart yet.</p>
            <Link href="/products">
              <Button className="mt-6">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Continue Shopping
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  // Calculate subtotal
  const subtotal = cart.items.reduce(
    (total, item) =>
      total +
      (typeof item.product_details?.price === "number"
        ? item.product_details.price
        : Number(item.product_details?.price)) *
        item.quantity,
    0,
  )

  return (
    <HeaderWrapper>
      <div className="container mx-auto py-12">
        <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
              <div className="p-6 border-b">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">Cart Items ({cart.item_count})</h2>
                  <Link href="/products">
                    <Button variant="ghost">
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Continue Shopping
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="p-6">
                {cart.items.map((item) => (
                  <CartItemComponent key={item.id} item={item} />
                ))}
              </div>
            </div>
          </div>

          <div>
            <CartSummary subtotal={subtotal} itemCount={cart.item_count} />
          </div>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
