"use client"

import { useSelector } from "react-redux"
import { useRouter } from "next/navigation"
import { useGetWishlistQuery, useRemoveItemMutation, useClearWishlistMutation } from "@/store/services/wishlistApi"
import { ProductCardListing } from "@/components/product/product-card-listing"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { useEffect } from "react"
import { Button } from "@/components/ui/button"

export default function WishlistPage() {
  const { isAuthenticated, user } = useSelector((state: any) => state.auth)
  const router = useRouter()
  const { data: wishlistData, isLoading: isWishlistLoading, error: wishlistError, refetch: refetchWishlist } = useGetWishlistQuery()
  const [removeWishlistItem, { isLoading: isRemoving }] = useRemoveItemMutation()
  const [clearWishlist, { isLoading: isClearing }] = useClearWishlistMutation()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login?next=/wishlist")
    }
  }, [isAuthenticated, router])

  const handleRemoveWishlist = async (product_id: number | undefined, product: any, item: any) => {
    // Fallback: try to get product_id from item.product.id if not present
    const validProductId = product_id || item?.product?.id;
    if (!validProductId || isNaN(Number(validProductId))) return;
    if (user && product && user.id === product.seller_id) {
      alert('You cannot remove your own product from wishlist.');
      return;
    }
    try {
      await removeWishlistItem({ product_id: validProductId });
      refetchWishlist();
    } catch (err) { 
      // Optionally handle error
    }
  }

  return (
    <HeaderWrapper>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">My Wishlist</h1>
        {wishlistData && wishlistData.items && wishlistData.items.length > 0 && (
          <div className="mb-4 flex justify-end">
            <Button
              variant="destructive"
              onClick={async () => { await clearWishlist(); refetchWishlist(); }}
              disabled={isClearing || isWishlistLoading}
            >
              {isClearing ? 'Clearing...' : 'Clear Wishlist'}
            </Button>
          </div>
        )}
        {isWishlistLoading ? (
          <div className="text-center py-8">Loading wishlist...</div>
        ) : wishlistError ? (
          <div className="text-center py-8 text-red-600">Failed to load wishlist.</div>
        ) : wishlistData && wishlistData.items && wishlistData.items.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {wishlistData.items.map((item: any) => (
              <div key={item.id} className="relative">
                <ProductCardListing product={item.product} />
                {!(user && item.product && user.id === item.product.seller_id) && (
                  <Button
                    className="absolute top-2 right-2 z-50 p-1 rounded-full bg-white/80 hover:bg-pink-100 border border-gray-200 text-pink-500"
                    onClick={() => handleRemoveWishlist(item.product_id, item.product, item)}
                    disabled={isRemoving}
                    aria-label="Remove from wishlist"
                  >
                    Remove
                  </Button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">Your wishlist is empty.</div>
        )}
      </div>
      <Footer />
    </HeaderWrapper>
  )
} 