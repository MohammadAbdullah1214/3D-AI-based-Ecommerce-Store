"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { useGetOrderQuery, useCancelOrderMutation } from "@/store/services/orderApi"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Package, Truck, AlertTriangle, Loader2 } from "lucide-react"
import Link from "next/link"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"

export default function OrderDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [isCancelling, setIsCancelling] = useState(false)

  const orderId = typeof params?.id === "string" ? Number.parseInt(params.id) : 0

  const { data: order, isLoading, error } = useGetOrderQuery(orderId)
  const [cancelOrder] = useCancelOrderMutation()

  const handleCancelOrder = async () => {
    if (!order) return

    if (window.confirm("Are you sure you want to cancel this order?")) {
      setIsCancelling(true)

      try {
        await cancelOrder(order.id).unwrap()
        toast({
          title: "Order Cancelled",
          description: "Your order has been cancelled successfully.",
        })
      } catch (error) {
        console.error("Error cancelling order:", error)
        toast({
          title: "Error",
          description: "There was a problem cancelling your order. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsCancelling(false)
      }
    }
  }

  // Helper function to get status steps
  const getOrderSteps = (status: string) => {
    const steps = [
      { name: "Pending", completed: true },
      { name: "Processing", completed: ["processing", "shipped", "delivered"].includes(status) },
      { name: "Shipped", completed: ["shipped", "delivered"].includes(status) },
      { name: "Delivered", completed: status === "delivered" },
    ]

    return steps
  }

  if (isLoading) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  if (error || !order) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-12">
          <Card>
            <CardHeader>
              <CardTitle className="text-red-500">Error Loading Order</CardTitle>
              <CardDescription>
                We couldn't find the order you're looking for. It may have been deleted or you may not have permission
                to view it.
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Button onClick={() => router.back()}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Go Back
              </Button>
            </CardFooter>
          </Card>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  const orderSteps = getOrderSteps(order.status)

  return (
    <HeaderWrapper>
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Order #{order.id}</CardTitle>
                    <CardDescription>Placed on {new Date(order.created_at).toLocaleDateString()}</CardDescription>
                  </div>
                  <Badge
                    variant={
                      order.status === "delivered"
                        ? "success"
                        : order.status === "cancelled"
                          ? "destructive"
                          : order.status === "pending"
                            ? "outline"
                            : "secondary"
                    }
                    className="text-sm py-1 px-3"
                  >
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Order Progress */}
                {order.status !== "cancelled" && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium mb-4">Order Progress</h3>
                    <div className="relative">
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                        <div
                          className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500`}
                          style={{
                            width: `${
                              order.status === "pending"
                                ? "25%"
                                : order.status === "processing"
                                  ? "50%"
                                  : order.status === "shipped"
                                    ? "75%"
                                    : order.status === "delivered"
                                      ? "100%"
                                      : "0%"
                            }`,
                          }}
                        ></div>
                      </div>
                      <div className="flex justify-between">
                        {orderSteps.map((step, index) => (
                          <div key={index} className="text-center">
                            <div
                              className={`
                              h-6 w-6 rounded-full mx-auto mb-1 flex items-center justify-center
                              ${step.completed ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-400"}
                            `}
                            >
                              {index + 1}
                            </div>
                            <div className="text-xs">{step.name}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Order Items */}
                <div>
                  <h3 className="text-sm font-medium mb-4">Order Items</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead className="text-right">Subtotal</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {order.items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">
                            {item.product_details?.name || `Product #${item.product}`}
                          </TableCell>
                          <TableCell>
                            $
                            {typeof item.price === "number"
                              ? item.price.toFixed(2)
                              : item.price
                                ? Number(item.price).toFixed(2)
                                : "0.00"}
                          </TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell className="text-right">
                            $
                            {typeof item.subtotal === "number"
                              ? item.subtotal.toFixed(2)
                              : item.subtotal
                                ? Number(item.subtotal).toFixed(2)
                                : "0.00"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Shipping Information */}
                <div>
                  <h3 className="text-sm font-medium mb-2">Shipping Information</h3>
                  <div className="bg-gray-50 p-4 rounded-md">
                    <p className="text-sm">{order.shipping_address}</p>

                    {order.tracking_number && (
                      <div className="mt-2 flex items-center text-sm">
                        <Truck className="h-4 w-4 mr-1 text-gray-500" />
                        <span>Tracking: {order.tracking_number}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Order Notes */}
                {order.notes && (
                  <div>
                    <h3 className="text-sm font-medium mb-2">Order Notes</h3>
                    <div className="bg-gray-50 p-4 rounded-md">
                      <p className="text-sm">{order.notes}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>
                      $
                      {typeof order.total_amount === "number"
                        ? order.total_amount.toFixed(2)
                        : order.total_amount
                          ? Number(order.total_amount).toFixed(2)
                          : "0.00"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>Included</span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>
                      $
                      {typeof order.total_amount === "number"
                        ? order.total_amount.toFixed(2)
                        : order.total_amount
                          ? Number(order.total_amount).toFixed(2)
                          : "0.00"}
                    </span>
                  </div>
                </div>

                <div className="mt-6 space-y-4">
                  <div className="flex items-center text-sm">
                    <Package className="h-4 w-4 mr-2 text-gray-500" />
                    <span>Payment Method: {order.payment?.payment_method || "Credit Card"}</span>
                  </div>

                  {order.status === "pending" && (
                    <Button
                      variant="destructive"
                      className="w-full"
                      onClick={handleCancelOrder}
                      disabled={isCancelling}
                    >
                      {isCancelling ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Cancelling...
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="mr-2 h-4 w-4" />
                          Cancel Order
                        </>
                      )}
                    </Button>
                  )}

                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/account/orders">View All Orders</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
