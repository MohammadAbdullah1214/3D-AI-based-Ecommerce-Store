"use client"

import { useState, useEffect } from "react"
import { useSelector } from "react-redux"
import type { RootState } from "@/store"
import { useRouter } from "next/navigation"
import ProfileForm from "@/components/account/profile-form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, User, Settings } from "lucide-react"
import Link from "next/link"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { useGetMeQuery } from "@/store/services/authApi"
import { useGetWishlistQuery, useRemoveItemMutation } from "@/store/services/wishlistApi"
import { ProductCardListing } from "@/components/product/product-card-listing"

export default function ProfilePage() {
  const { isAuthenticated, user } = useSelector((state: RootState) => state.auth)
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)

  // Fetch user data if not already available
  const { data: userData, isLoading: isLoadingUser } = useGetMeQuery(undefined, {
    skip: !isAuthenticated || !!user,
  })

  // Wishlist
  const { data: wishlistData, isLoading: isWishlistLoading, error: wishlistError, refetch: refetchWishlist } = useGetWishlistQuery()
  const [removeWishlistItem, { isLoading: isRemoving }] = useRemoveItemMutation()

  const handleRemoveWishlist = async (product_id: number, product: any) => {
    // Prevent seller from removing their own product from wishlist (shouldn't be possible, but extra check)
    if (user && product && user.id === product.seller_id) {
      alert('You cannot remove your own product from wishlist.');
      return;
    }
    try {
      await removeWishlistItem({ product_id })
      refetchWishlist()
    } catch (err) {
      // Optionally handle error
    }
  }

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }
    setIsLoading(isLoadingUser)
  }, [isAuthenticated, isLoadingUser, router])

  if (!isAuthenticated) {
    return null // Will redirect to login
  }

  if (isLoading) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto px-4 py-16 flex justify-center">
          <div className="animate-spin h-12 w-12 border-4 border-purple-500 rounded-full border-t-transparent"></div>
        </div>
        <Footer />
      </HeaderWrapper>
    )
  }

  const currentUser = userData || user

  return (
    <HeaderWrapper>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-full">
                <User className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Profile Settings</h1>
                <p className="text-gray-600 dark:text-gray-400">
                  Manage your account information and preferences
                </p>
              </div>
            </div>
          </div>

          {/* Wishlist Section */}
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">My Wishlist</h2>
            {isWishlistLoading ? (
              <div className="text-center py-8">Loading wishlist...</div>
            ) : wishlistError ? (
              <div className="text-center py-8 text-red-600">Failed to load wishlist.</div>
            ) : wishlistData && wishlistData.items && wishlistData.items.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {wishlistData.items.map((item: any) => (
                  <div key={item.id} className="relative">
                    <ProductCardListing product={item.product} />
                    {/* Only show remove button if not seller's own product */}
                    {!(user && item.product && user.id === item.product.seller_id) && (
                      <button
                        className="absolute top-2 right-2 z-50 p-1 rounded-full bg-white/80 hover:bg-pink-100 border border-gray-200 text-pink-500"
                        onClick={() => handleRemoveWishlist(item.product_id, item.product)}
                        disabled={isRemoving}
                        aria-label="Remove from wishlist"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">Your wishlist is empty.</div>
            )}
          </div>

          {/* Profile Card */}
          <Card className="backdrop-blur-sm bg-white/10 dark:bg-gray-900/30 border border-gray-200 dark:border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <ProfileForm user={currentUser} />
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link href="/account/orders">
              <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                    <svg className="h-5 w-5 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold">Order History</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">View your past orders</p>
                  </div>
                </div>
              </Card>
            </Link>

            <Link href="/dashboard">
              <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full">
                    <svg className="h-5 w-5 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold">Dashboard</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Go to your dashboard</p>
                  </div>
                </div>
              </Card>
            </Link>
          </div>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
} 