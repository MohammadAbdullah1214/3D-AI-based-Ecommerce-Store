"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProfileForm from "@/components/account/profile-form"
import OrderHistory from "@/components/account/order-history"
import { Card } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

export default function AccountPage() {
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Fetch user data from API
    const fetchUser = async () => {
      try {
        // In a real app, you would fetch from your API
        // const response = await fetch('/api/users/me', {
        //   headers: {
        //     'Authorization': `Bearer ${localStorage.getItem('token')}`
        //   }
        // });
        // const data = await response.json();

        // Mock user data
        const mockUser = {
          id: "1",
          username: "johndoe",
          email: "john.doe@example.com",
          role: "customer",
          address: "123 Main St, Anytown, USA",
        }

        setUser(mockUser)
      } catch (error) {
        toast({
          title: "Error loading profile",
          description: "Please try again later.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchUser()
  }, [toast])

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16 flex justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-purple-500 rounded-full border-t-transparent"></div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Please log in to view your account</h1>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">My Account</h1>

      <Card className="backdrop-blur-sm bg-white/10 dark:bg-gray-900/30 border border-gray-200 dark:border-gray-800">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="orders">Order History</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="p-6">
            <ProfileForm user={user} />
          </TabsContent>

          <TabsContent value="orders" className="p-6">
            <OrderHistory />
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  )
}
