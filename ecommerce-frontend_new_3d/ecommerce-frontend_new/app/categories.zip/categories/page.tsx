"use client"
import { useEffect } from "react"
import { useGetCategoriesQuery } from "@/store/services/productApi"
import HeaderWrapper from "../header-wrapper"
import Footer from "@/components/layout/footer"
import CategoryCard from "@/components/home/category-card"
import { Skeleton } from "@/components/ui/skeleton"

export default function CategoriesPage() {
  // Fetch categories from API
  const { data: categories, isLoading, error } = useGetCategoriesQuery()

  // Log for debugging
  useEffect(() => {
    console.log("Categories data:", categories)
    console.log("Categories error:", error)
  }, [categories, error])

  // Create a mapping of parent categories and their children
  const getCategoryTree = () => {
    if (!categories) return { rootCategories: [], childrenMap: {} }

    const childrenMap = {}
    categories.forEach((cat) => {
      if (cat.parent) {
        if (!childrenMap[cat.parent]) {
          childrenMap[cat.parent] = []
        }
        childrenMap[cat.parent].push(cat)
      }
    })

    // Get root categories (those without a parent)
    const rootCategories = categories.filter((cat) => !cat.parent)

    return { rootCategories, childrenMap }
  }

  const { rootCategories, childrenMap } = getCategoryTree()

  // Fallback category data with image paths and product counts
  const fallbackCategories = [
    { id: 1, name: "Electronics", image: "/images/categories/electronics.jpg", count: "120+ Products" },
    { id: 2, name: "Fashion", image: "/images/categories/fashion.jpg", count: "250+ Products" },
    { id: 3, name: "Home & Garden", image: "/images/categories/home-garden.jpg", count: "180+ Products" },
    { id: 4, name: "Beauty", image: "/images/categories/beauty.jpg", count: "95+ Products" },
    { id: 5, name: "Sports", image: "/images/categories/sports.jpg", count: "75+ Products" },
    { id: 6, name: "Toys", image: "/images/categories/toys.jpg", count: "60+ Products" },
    { id: 7, name: "Books", image: "/images/categories/books.jpg", count: "110+ Products" },
    { id: 8, name: "Jewelry", image: "/images/categories/jewelry.jpg", count: "45+ Products" },
  ]

  return (
    <HeaderWrapper>
      <main className="flex-1">
        {/* Hero Banner */}
        <section className="relative bg-gradient-to-r from-purple-600 to-blue-600 py-16">
          <div className="absolute inset-0 bg-grid-white/[0.05] [mask-image:linear-gradient(0deg,#fff,rgba(255,255,255,0.5))]"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center text-white">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Shop by Category</h1>
              <p className="text-lg text-purple-100">Browse our wide selection of products across popular categories</p>
            </div>
          </div>
        </section>

        {/* Categories Grid */}
        <section className="py-16 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {Array.from({ length: 8 }).map((_, index) => (
                  <div key={index} className="flex flex-col space-y-3">
                    <Skeleton className="h-[300px] w-full rounded-xl" />
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : error || !categories || categories.length === 0 ? (
              // Fallback to static data if API fails
              <div>
                <div className="mb-8 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                  <h3 className="text-yellow-800 font-medium">API Connection Issue</h3>
                  <p className="mt-2">We couldn't load categories from the API. Showing fallback data instead.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                  {fallbackCategories.map((category) => (
                    <CategoryCard
                      key={category.id}
                      name={category.name}
                      image={category.image}
                      count={category.count}
                      href={`/categories/${category.id}`}
                    />
                  ))}
                </div>
              </div>
            ) : (
              // Display categories from API
              <div>
                {rootCategories.length > 0 ? (
                  <div className="space-y-12">
                    {rootCategories.map((rootCategory) => (
                      <div key={rootCategory.id} className="space-y-6">
                        <h2 className="text-2xl font-bold border-b pb-2">{rootCategory.name}</h2>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                          {/* Root category card */}
                          <CategoryCard
                            key={rootCategory.id}
                            name={`All ${rootCategory.name}`}
                            image={`/images/categories/${rootCategory.name.toLowerCase().replace(/\s+/g, "-")}.jpg`}
                            count="Browse All"
                            href={`/categories/${rootCategory.id}`}
                          />

                          {/* Child categories */}
                          {childrenMap[rootCategory.id]?.map((childCategory) => (
                            <CategoryCard
                              key={childCategory.id}
                              name={childCategory.name}
                              image={`/placeholder.svg?height=300&width=300&query=${encodeURIComponent(childCategory.name)}`}
                              count="View Products"
                              href={`/categories/${childCategory.id}`}
                            />
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                    {categories.map((category) => (
                      <CategoryCard
                        key={category.id}
                        name={category.name}
                        image={`/placeholder.svg?height=300&width=300&query=${encodeURIComponent(category.name)}`}
                        count="View Products"
                        href={`/categories/${category.id}`}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </HeaderWrapper>
  )
}
