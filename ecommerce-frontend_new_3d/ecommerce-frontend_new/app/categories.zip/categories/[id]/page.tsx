"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { useGetProductsByCategoryQuery, useGetCategoriesQuery } from "@/store/services/productApi"
import { useAddToCartMutation } from "@/store/services/cartApi"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { ShoppingCart, Star, Filter, ChevronDown, ArrowLeft, CuboidIcon as Cube, Play } from "lucide-react"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { formatCurrency } from "@/utils/format-utils"
import { hasMediaType } from "@/utils/product-utils"
import { useAuth } from "@/hooks/useAuth"
import type { Product, Category } from '@/app/types';

export default function CategoryDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const categoryId = typeof params?.id === "string" ? Number.parseInt(params.id) : Number(params.id);

  // State for mobile filter visibility
  const [showMobileFilters, setShowMobileFilters] = useState(false)
  const [sortBy, setSortBy] = useState("relevance")

  // Fetch category data
  const { data: categories } = useGetCategoriesQuery()
  const category = categories?.find((c) => c.id === categoryId)

  // Fetch products for this category
  const { data: products, isLoading, error } = useGetProductsByCategoryQuery(categoryId)

  // Add to cart functionality
  const [addToCart, { isLoading: isAddingToCart }] = useAddToCartMutation()
      const { currentUser, isLoadingUser } = useAuth();
  const user = currentUser;
  const isAuthenticated = !!currentUser;

  const handleAddToCart = async (product: Product) => {
    if (!isAuthenticated) {
      router.push('/login')
      return
    }
    if (user && product && (user.id === product.seller_id || user.username === product.seller_username)) {
      toast({
        title: 'Not allowed',
        description: 'You cannot add your own product to cart.',
        variant: 'destructive',
      })
      return
    }
    try {
      await addToCart({
        product_id: product.id,
        quantity: 1,
      }).unwrap()
      toast({
        title: "Added to cart",
        description: "Product has been added to your cart.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add product to cart.",
        variant: "destructive",
      })
    }
  }

  // Get parent categories for breadcrumbs
  const getParentCategories = () => {
    if (!categories || !category) return []

    const result: Category[] = []
    let currentParentId = category.parent_id

    while (currentParentId) {
      const parentCategory = categories.find((c: Category) => c.id === currentParentId)
      if (parentCategory) {
        result.unshift(parentCategory)
        currentParentId = parentCategory.parent_id
      } else {
        break
      }
    }

    return result
  }

  const parentCategories = getParentCategories()

  // Get subcategories
  const subcategories = categories?.filter((c: Category) => c.parent_id === categoryId) || []

  return (
    <HeaderWrapper>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb navigation */}
        <div className="flex items-center mb-6 text-sm">
          <Link href="/categories" className="text-gray-500 hover:text-gray-700">
            Categories
          </Link>
          {parentCategories.map((parent, index) => (
            <div key={parent.id} className="flex items-center">
              <span className="mx-2 text-gray-400">/</span>
              <Link href={`/categories/${parent.id}`} className="text-gray-500 hover:text-gray-700">
                {parent.name}
              </Link>
            </div>
          ))}
          {category && (
            <>
              <span className="mx-2 text-gray-400">/</span>
              <span className="font-medium">{category.name}</span>
            </>
          )}
        </div>

        {/* Category header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{category?.name || "Category"}</h1>
          <p className="text-gray-600">
            Browse our selection of {category?.name.toLowerCase() || "products"} and find exactly what you're looking
            for.
          </p>
        </div>

        {/* Subcategories */}
        {subcategories.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Subcategories</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {subcategories.map((subcat) => (
                <Link key={subcat.id} href={`/categories/${subcat.id}`}>
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow text-center">
                    {subcat.name}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Filters sidebar */}
          <aside className={`w-full lg:w-64 shrink-0 ${showMobileFilters ? "block" : "hidden lg:block"}`}>
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="font-medium mb-4">Filters</h3>

              {/* Mobile filter button */}
              <div className="lg:hidden mb-4">
                <Button
                  variant="outline"
                  className="w-full flex items-center justify-between"
                  onClick={() => setShowMobileFilters(!showMobileFilters)}
                >
                  <span className="flex items-center">
                    <Filter className="h-4 w-4 mr-2" />
                    Filters
                  </span>
                  <ChevronDown className={`h-4 w-4 transition-transform ${showMobileFilters ? "rotate-180" : ""}`} />
                </Button>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="font-medium mb-2">Price Range</h4>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="price-1" className="mr-2" />
                    <label htmlFor="price-1">Under $25</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="price-2" className="mr-2" />
                    <label htmlFor="price-2">$25 to $50</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="price-3" className="mr-2" />
                    <label htmlFor="price-3">$50 to $100</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="price-4" className="mr-2" />
                    <label htmlFor="price-4">$100 to $200</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="price-5" className="mr-2" />
                    <label htmlFor="price-5">$200 & Above</label>
                  </div>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Customer Reviews */}
              <div className="mb-6">
                <h4 className="font-medium mb-2">Customer Reviews</h4>
                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map((rating) => (
                    <div key={rating} className="flex items-center">
                      <input type="checkbox" id={`rating-${rating}`} className="mr-2" />
                      <label htmlFor={`rating-${rating}`} className="flex items-center">
                        {Array(5)
                          .fill(0)
                          .map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                            />
                          ))}
                        <span className="ml-1 text-sm text-gray-600">& Up</span>
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="my-4" />

              {/* Availability */}
              <div className="mb-6">
                <h4 className="font-medium mb-2">Availability</h4>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="in-stock" className="mr-2" />
                    <label htmlFor="in-stock">In Stock</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="out-of-stock" className="mr-2" />
                    <label htmlFor="out-of-stock">Out of Stock</label>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Product grid */}
          <main className="flex-1">
            {/* Sort options */}
            <div className="bg-white rounded-lg shadow-sm p-3 mb-4 flex justify-between items-center">
              <div className="flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                <span className="text-sm font-medium">Sort by:</span>
              </div>
              <select
                className="text-sm border-0 bg-transparent focus:ring-0"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="relevance">Relevance</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Avg. Customer Review</option>
                <option value="newest">Newest Arrivals</option>
              </select>
            </div>

            {/* Products grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Card key={index} className="animate-pulse">
                    <div className="aspect-square bg-gray-200"></div>
                    <CardContent className="p-4">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-6 bg-gray-200 rounded w-1/4 mt-4"></div>
                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                      <div className="h-10 bg-gray-200 rounded w-full"></div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : error ? (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                <h3 className="text-xl font-medium mb-4">Error loading products</h3>
                <p className="text-gray-600 mb-6">There was a problem loading products for this category.</p>
                <Button onClick={() => router.back()}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Go Back
                </Button>
              </div>
            ) : products && products.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {products.map((product) => (
                  <Card key={product.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <Link href={`/products/${product.id}`} className="block">
                      <div className="aspect-square relative">
                        <Image
                          src={
                            product.images && product.images.length > 0
                              ? product.images[0].image_url || "/placeholder-300px-height.png"
                              : "/placeholder-300px-height.png"
                          }
                          alt={product.name}
                          fill
                          className="object-cover transition-transform hover:scale-105"
                        />

                        {product.discount_price && product.discount_price < product.price && (
                          <Badge className="absolute top-2 left-2 bg-red-500">
                            Save ${(product.price - product.discount_price).toFixed(2)}
                          </Badge>
                        )}

                        {/* Media type badges */}
                        <div className="absolute top-2 right-2 flex flex-col gap-1">
                          {hasMediaType(product, "model_3d") && (
                            <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1">
                              <Cube className="h-3 w-3" />
                              <span className="text-xs">3D</span>
                            </Badge>
                          )}
                          {hasMediaType(product, "video") && (
                            <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
                              <Play className="h-3 w-3" />
                              <span className="text-xs">Video</span>
                            </Badge>
                          )}
                        </div>
                      </div>
                    </Link>

                    <CardContent className="p-4">
                      <Link href={`/products/${product.id}`} className="block">
                        <h3 className="font-medium text-sm line-clamp-2 mb-1 hover:text-blue-600">{product.name}</h3>
                      </Link>

                      <div className="flex items-center mb-1">
                        <div className="flex items-center">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-3 w-3 ${
                                star <= Math.round(Number(product.average_rating) || 0)
                                  ? "text-yellow-400 fill-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="ml-1 text-xs text-gray-600">({product.reviews?.length || 0})</span>
                      </div>

                      <div className="mt-2">
                        <div className="flex items-baseline">
                          <span className="text-lg font-bold">${formatCurrency(product.price)}</span>
                          {product.discount_price && (
                            <span className="ml-2 text-sm text-gray-500 line-through">
                              ${formatCurrency(product.discount_price)}
                            </span>
                          )}
                        </div>

                        <div className="text-xs text-gray-600 mt-1">
                          {product.stock ?? 0 > 0 ? (
                            <span>In stock</span>
                          ) : (
                            <span className="text-red-600">Out of stock</span>
                          )}
                        </div>
                      </div>

                      <Button
                        size="sm"
                        className="w-full mt-3 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-medium"
                        onClick={() => handleAddToCart(product)}
                        disabled={!product.stock || product.stock <= 0}
                      >
                        <ShoppingCart className="h-3 w-3 mr-1" />
                        Add to cart
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                <h3 className="text-xl font-medium mb-4">No products found</h3>
                <p className="text-gray-600 mb-6">There are no products available in this category yet.</p>
                <Link href="/categories">
                  <Button>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Browse Categories
                  </Button>
                </Link>
              </div>
            )}
          </main>
        </div>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
