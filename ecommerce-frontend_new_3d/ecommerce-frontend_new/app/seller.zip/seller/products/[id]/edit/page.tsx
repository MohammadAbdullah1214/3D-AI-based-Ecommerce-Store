"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { useParams, useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { toast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import {
  useGetProductQuery,
  useGetCategoriesQuery,
  useUpdateProductMutation,
  useUploadProductFilesMutation,
  useGenerate3dModelMutation,
  useCancelGenerationMutation,
  useGetGenerationStatusQuery,
} from "@/store/services/productApi"
import { useGetProductMediaQuery } from "@/store/services/mediaApi"
import { MediaUpload } from "@/components/product/media-upload"
import { ThreeDGenerationPanel } from "@/components/product/3d-generation-panel"
import { AuthDebug } from "@/components/debug/auth-debug"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { ArrowLeft, Loader2, CuboidIcon, Play } from "lucide-react"
import Link from "next/link"
import { getProductStock, getMediaUrl } from "@/utils/product-utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProductGallery } from "@/components/product/product-gallery"
import Simple3DViewer from "@/components/product/simple-3d-viewer"

// Define the form schema with Zod
const formSchema = z.object({
  name: z.string().min(3, { message: "Product name must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  price: z.coerce.number().positive({ message: "Price must be a positive number" }),
  discount_price: z.coerce.number().nonnegative().optional().nullable(),
  stock: z.coerce.number().int().nonnegative({ message: "Stock must be a non-negative integer" }),
  category: z.string().min(1, { message: "Please select a category" }),
  status: z.enum(["draft", "active", "inactive"]).default("draft"),
  is_active: z.boolean().default(true),
  weight: z.coerce.number().nonnegative().optional().nullable(),
  length: z.coerce.number().nonnegative().optional().nullable(),
  width: z.coerce.number().nonnegative().optional().nullable(),
  height: z.coerce.number().nonnegative().optional().nullable(),
  mediaFiles: z
    .array(
      z.object({
        file: z.instanceof(File),
        fileType: z.enum(["image", "video", "model_3d"]),
      }),
    )
    .optional()
    .default([]),
}).superRefine((data, ctx) => {
  if (
    data.discount_price !== null &&
    data.discount_price !== undefined &&
    data.discount_price >= data.price
  ) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Discount price must be less than price",
      path: ["discount_price"],
    });
  }
});

type FormValues = z.infer<typeof formSchema>

export default function EditProductPage() {
  const params = useParams()
  const productId = typeof params?.id === "string" ? Number.parseInt(params.id) : 0
  const router = useRouter()

  // State
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isPollingStatus, setIsPollingStatus] = useState(false)

  // API Hooks
  const {
    data: product,
    isLoading: isLoadingProduct,
    error: productError,
    refetch: refetchProduct,
  } = useGetProductQuery(productId, {
    skip: !productId,
    refetchOnMountOrArgChange: true,
  })
  const { data: categories, isLoading: categoriesLoading } = useGetCategoriesQuery()
  const [updateProduct, { isLoading: isUpdating }] = useUpdateProductMutation()
  const [uploadProductFiles, { isLoading: isUploading }] = useUploadProductFilesMutation()
  const { data: productMedia = [], isLoading: isLoadingMedia } = useGetProductMediaQuery(productId, {
    skip: !productId,
  })

  // 3D Model Hooks
  const { data: generationStatus } = useGetGenerationStatusQuery(productId, {
    pollingInterval: isPollingStatus ? 10000 : 0, // Poll only when a job is active
    skip: !productId,
  })
  const [generate3dModel, { isLoading: isGenerating }] = useGenerate3dModelMutation()
  const [cancelGeneration, { isLoading: isCancelling }] = useCancelGenerationMutation()

  // Form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      discount_price: null,
      stock: 0,
      category: "",
      status: "draft",
      is_active: true,
      weight: null,
      length: null,
      width: null,
      height: null,
      mediaFiles: [],
    },
  })

  // Effect to reset form when product data loads
  useEffect(() => {
    if (product) {
      form.reset({
        name: product.name,
        description: product.description || "",
        price: typeof product.price === "number" ? product.price : Number(product.price),
        discount_price: product.discount_price ? Number(product.discount_price) : null,
        stock: getProductStock(product),
        category: String(product.category_id ?? product.category?.id ?? ''),
        status: product.status || "draft",
        is_active: typeof product.is_active === 'boolean' ? product.is_active : true,
        weight: product.weight ?? null,
        length: product.length ?? null,
        width: product.width ?? null,
        height: product.height ?? null,
        mediaFiles: [],
      })
    }
  }, [product, form])

  // Effect to control polling based on generation status
  useEffect(() => {
    if (generationStatus) {
      const isActive =
        generationStatus.status === "pending" || generationStatus.status === "processing"
      const isFinished =
        generationStatus.status === "completed" ||
        generationStatus.status === "failed" ||
        generationStatus.status === "cancelled"

      if (isFinished) {
        // Stop polling when the job is done
        setIsPollingStatus(false)
        // Refetch product data only on success to get the updated `has_3d_model` flag
        if (generationStatus.status === "completed") {
          refetchProduct()
        }
      } else if (isActive !== isPollingStatus) {
        // Start polling if the job is active
        setIsPollingStatus(isActive)
      }
    }
  }, [generationStatus, isPollingStatus, refetchProduct])

  // Handle form submission
  const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true)
    try {
      // Step 1: Update product's text/numeric data
      const { mediaFiles, category, ...productDataRest } = values
      console.log("Form submission - mediaFiles:", mediaFiles)
      console.log("Form submission - productData:", productDataRest)
      
      await updateProduct({ 
        id: productId, 
        ...productDataRest,
        category_id: Number(category) // Use category_id for backend
      }).unwrap()
      toast({ title: "Product details saved." })

      // Step 2: Upload new media files if any
      if (mediaFiles && mediaFiles.length > 0) {
        console.log("Uploading media files:", mediaFiles)
        toast({ title: "Uploading new media...", description: `Uploading ${mediaFiles.length} file(s).`})
        const formData = new FormData()
        
        // Group files by type and append them with the correct field names
        const images = mediaFiles.filter(item => item.fileType === 'image')
        const videos = mediaFiles.filter(item => item.fileType === 'video')
        const models = mediaFiles.filter(item => item.fileType === 'model_3d')
        
        console.log("Grouped files - images:", images.length, "videos:", videos.length, "models:", models.length)
        
        // Append all files to the 'images' field, as required by backend
        images.forEach((item) => {
          formData.append("images", item.file)
        })
        videos.forEach((item) => {
          formData.append("images", item.file)
        })
        models.forEach((item) => {
          formData.append("images", item.file)
        })

        await uploadProductFiles({ productId, data: formData }).unwrap()
        toast({ title: "New media uploaded successfully." })
        
        // Clear the media files from the form after successful upload
        form.setValue("mediaFiles", [])
        // Clear the MediaUpload component's state
        if ((window as any).clearMediaUploadFiles) {
          (window as any).clearMediaUploadFiles()
        }
      } else {
        console.log("No media files to upload")
      }

      toast({
        title: "Product Updated",
        description: "Your product has been successfully updated.",
      })
      router.push("/dashboard?tab=products")
    } catch (error) {
      console.error("Error updating product:", error)
      toast({
        title: "Update Failed",
        description: "There was an error updating your product. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Handle 3D model generation start
  const handleGenerationStart = useCallback(
    async (detailLevel: string, angleMapping: Record<string, number>, clothingType: string) => {
      try {
        await generate3dModel({
          productId,
          detailLevel: detailLevel as "low" | "medium" | "high",
          angleMapping,
          clothingType,
        }).unwrap()
        toast({
          title: "3D Model Generation Started",
          description: "Your model is being created. You can monitor the progress here.",
        })
      } catch (error: any) {
        console.error("Error starting generation:", error)
        const errorMessage =
          error.data?.detail || "Could not start the 3D model generation process. Please check the console."
        toast({
          title: "Generation Failed to Start",
          description: errorMessage,
          variant: "destructive",
        })
      }
    },
    [productId, generate3dModel],
  )

  // Handle 3D model generation cancellation
  const handleCancelGeneration = useCallback(async () => {
    try {
      await cancelGeneration({ productId }).unwrap()
      toast({
        title: "Generation Cancelled",
        description: "The 3D model generation process has been cancelled.",
      })
    } catch (error) {
      toast({
        title: "Cancellation Failed",
        description: "Could not cancel the generation process.",
        variant: "destructive",
      })
    }
  }, [productId, cancelGeneration])

  // Separate media by type for preview
  const previewImages = (productMedia || []).filter(item => item.file_type === 'image')
  const previewModels = (productMedia || []).filter(item => item.file_type === 'model' || item.file_type === 'model_3d')
  const previewVideos = (productMedia || []).filter(item => item.file_type === 'video')

  if (isLoadingProduct || categoriesLoading) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-10 flex justify-center items-center min-h-[60vh]">
          <Loader2 className="h-12 w-12 animate-spin text-gray-500" />
        </div>
      </HeaderWrapper>
    )
  }

  if (productError || !product) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-10">
          <Card className="max-w-3xl mx-auto border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="text-red-800">Error Loading Product</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-700">The product could not be loaded. Please try again later.</p>
              <Button asChild variant="outline" className="mt-4">
                <Link href="/dashboard?tab=products">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Products
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </HeaderWrapper>
    )
  }

  const overallLoading = isSubmitting || isUpdating || isUploading || isLoadingMedia

  return (
    <HeaderWrapper>
      <div className="container mx-auto py-10">
        {/* Product Media Preview */}
        <div className="mb-8 space-y-6">
          {/* Images Preview */}
          {previewImages.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Product Images</h3>
              <ProductGallery 
                media={previewImages.map((item, idx) => ({ 
                  id: item.id || idx, 
                  url: item.file || item.url || '/placeholder.svg', 
                  file_type: 'image' 
                }))} 
                productName={product?.name || "Product"} 
              />
            </div>
          )}

          {/* 3D Models Preview */}
          {previewModels.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <CuboidIcon className="h-4 w-4" />
                3D Models
              </h3>
              <Simple3DViewer
                modelUrl={previewModels[0]?.file}
                productName={product?.name || "Product"}
                isDefault={false}
                width={500}
                height={400}
                showControls={true}
                showARButton={true}
              />
            </div>
          )}

          {/* Videos Preview */}
          {previewVideos.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <Play className="h-4 w-4" />
                Product Videos
              </h3>
              <div className="grid grid-cols-1 gap-2">
                {previewVideos.slice(0, 2).map((video, index) => (
                  <div key={index} className="relative aspect-video overflow-hidden rounded-md border">
                    <video
                      src={video.file}
                      controls
                      className="w-full h-full object-cover"
                      poster="/placeholder.svg?height=200&width=300"
                    >
                      Your browser does not support the video tag.
                    </video>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="max-w-5xl mx-auto">
              <div className="flex justify-between items-center mb-6">
                <Button asChild variant="outline">
                  <Link href="/dashboard?tab=products">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back to Products
                  </Link>
                </Button>
                <h1 className="text-2xl font-bold">Edit Product</h1>
                <Button type="submit" disabled={overallLoading}>
                  {overallLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Save Changes
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column */}
                <div className="lg:col-span-2 space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Product Details</CardTitle>
                      <CardDescription>Update the name, description, and other core details.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Product Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., 'Wooden Chair'" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Describe your product in detail..." rows={6} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Media Management</CardTitle>
                      <CardDescription>Upload images, videos, or 3D models for your product.</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="media" className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="media">Media</TabsTrigger>
                          <TabsTrigger value="3d-model">3D Model</TabsTrigger>
                        </TabsList>
                        <TabsContent value="media">
                          <MediaUpload
                            productId={productId}
                            onFilesChange={(files) => {
                              const getFileType = (
                                mimeType: string,
                              ): "image" | "video" | "model_3d" => {
                                if (mimeType.startsWith("image/")) return "image"
                                if (mimeType.startsWith("video/")) return "video"
                                return "model_3d" // Fallback for .glb, .gltf
                              }
                              const formattedFiles = files.map((file) => ({
                                file: file,
                                fileType: getFileType(file.type),
                              }))
                              form.setValue("mediaFiles", formattedFiles)
                            }}
                            existingMedia={productMedia}
                            isUploading={isUploading}
                          />
                        </TabsContent>
                        <TabsContent value="3d-model">
                          <ThreeDGenerationPanel
                            productId={productId}
                            productMedia={productMedia}
                            has3dModel={product?.has_3d_model || false}
                            generationStatus={generationStatus}
                            isGenerating={isGenerating}
                            isCancelling={isCancelling}
                            onGenerationStart={handleGenerationStart}
                            onCancel={handleCancelGeneration}
                          />
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                </div>

                {/* Right Column */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Pricing & Inventory</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price ($)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" placeholder="e.g., 99.99" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="discount_price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Discount Price ($) (Optional)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" placeholder="e.g., 79.99" {...field} value={field.value ?? ''} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="stock"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Stock Quantity</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="e.g., 100" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Category</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Product Category</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {categories?.map((cat) => (
                                  <SelectItem key={cat.id} value={String(cat.id)}>
                                    {cat.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* Additional Info */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Additional Info</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="inactive">Inactive</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="is_active"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                            <div className="space-y-0.5">
                              <FormLabel>Is Active</FormLabel>
                            </div>
                            <FormControl>
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={e => field.onChange(e.target.checked)}
                                className="form-checkbox h-5 w-5 text-blue-600"
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="weight"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Weight (kg)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 1.5" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="length"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Length (cm)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 30" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="width"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Width (cm)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 20" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="height"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Height (cm)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 10" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="flex justify-end mt-8">
                <Button type="submit" disabled={overallLoading} size="lg">
                  {overallLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Save All Changes
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}
