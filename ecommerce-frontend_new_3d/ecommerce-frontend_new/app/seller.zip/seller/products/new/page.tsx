"use client"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { toast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useGetCategoriesQuery, useCreateProductMutation } from "@/store/services/productApi"
import HeaderWrapper from "@/app/header-wrapper"
import Footer from "@/components/layout/footer"
import { ArrowLeft, Loader2, Upload, Image, Video, CuboidIcon, Info, CheckCircle, AlertCircle, Camera, FileImage, FileVideo, File, Play } from "lucide-react"
import Link from "next/link"
import { ProductGallery } from "@/components/product/product-gallery"
import Simple3DViewer from "@/components/product/simple-3d-viewer"

const formSchema = z.object({
  name: z.string().min(3, { message: "Product name must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  price: z.coerce.number().positive({ message: "Price must be a positive number" }),
  discount_price: z.coerce.number().nonnegative().optional().nullable(),
  stock: z.coerce.number().int().nonnegative({ message: "Stock must be a non-negative integer" }),
  category: z.string().min(1, { message: "Please select a category" }),
  status: z.enum(["draft", "active", "inactive"]).default("draft"),
  is_active: z.boolean().default(true),
  weight: z.coerce.number().nonnegative().optional().nullable(),
  length: z.coerce.number().nonnegative().optional().nullable(),
  width: z.coerce.number().nonnegative().optional().nullable(),
  height: z.coerce.number().nonnegative().optional().nullable(),
  // variants: z.array(z.object({ sku: z.string(), price_adjustment: z.number().optional(), stock: z.number().optional() })).optional(),
}).superRefine((data, ctx) => {
  if (
    data.discount_price !== null &&
    data.discount_price !== undefined &&
    data.discount_price >= data.price
  ) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Discount price must be less than price",
      path: ["discount_price"],
    });
  }
});

type FormValues = z.infer<typeof formSchema>

export default function NewProductPage() {
  const router = useRouter()
  const [selectedFiles, setSelectedFiles] = useState<{
    images: File[]
    videos: File[]
    models: File[]
  }>({
    images: [],
    videos: [],
    models: [],
  })

  const imageInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const modelInputRef = useRef<HTMLInputElement>(null)

  const { data: categories, isLoading: categoriesLoading } = useGetCategoriesQuery()
  const [createProduct, { isLoading: isCreating }] = useCreateProductMutation()

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      discount_price: null,
      stock: 0,
      category: "",
      status: "draft",
      is_active: true,
      weight: null,
      length: null,
      width: null,
      height: null,
      // variants: [],
    },
  })

  const handleFileSelect = (type: 'images' | 'videos' | 'models', files: FileList | null) => {
    console.log(`handleFileSelect called for type: ${type}`, files)
    if (!files) {
      console.log("No files selected")
      return
    }
    const fileArray = Array.from(files)
    console.log(`Selected ${fileArray.length} files for ${type}:`, fileArray.map(f => f.name))
    setSelectedFiles(prev => {
      const updated = {
        ...prev,
        [type]: [...prev[type], ...fileArray]
      }
      console.log("Updated selectedFiles:", updated)
      return updated
    })
  }

  const removeFile = (type: 'images' | 'videos' | 'models', index: number) => {
    console.log(`Removing file at index ${index} from ${type}`)
    setSelectedFiles(prev => {
      const updated = {
        ...prev,
        [type]: prev[type].filter((_, i) => i !== index)
      }
      console.log("Updated selectedFiles after removal:", updated)
      return updated
    })
  }

  const onSubmit = async (values: FormValues) => {
    try {
      if (selectedFiles.images.length === 0 && selectedFiles.videos.length === 0 && selectedFiles.models.length === 0) {
        toast({
          title: "No Media Selected",
          description: "Please select at least one image, video, or 3D model for your product.",
          variant: "destructive",
        })
        return;
      }

      console.log("Form submission started with values:", values)
      console.log("Selected files:", selectedFiles)
      
      const formData = new FormData()
      formData.append("name", values.name)
      formData.append("description", values.description)
      formData.append("price", String(values.price))
      formData.append("stock", String(values.stock))
      formData.append("category", values.category)
      if (values.discount_price) {
        formData.append("discount_price", String(values.discount_price))
      }
      // Append all files to the 'images' field, as required by backend
      selectedFiles.images.forEach((file) => {
        formData.append("images", file)
      })
      selectedFiles.videos.forEach((file) => {
        formData.append("images", file)
      })
      selectedFiles.models.forEach((file) => {
        formData.append("images", file)
      })

      console.log("FormData entries:")
      Array.from(formData.entries()).forEach(([key, value]) => {
        console.log(key, value)
      })

      const newProduct = await createProduct(formData).unwrap()
      toast({
        title: "Product Created!",
        description: `"${newProduct.name}" has been created successfully with ${selectedFiles.images.length + selectedFiles.videos.length + selectedFiles.models.length} media files.`,
      })
      router.push("/dashboard?tab=products")
    } catch (error) {
      console.error("Error creating product:", error)
      toast({
        title: "Creation Failed",
        description: "There was an error creating your product. Please check your input and try again.",
        variant: "destructive",
      })
    }
  }

  if (categoriesLoading) {
    return (
      <HeaderWrapper>
        <div className="container mx-auto py-10 flex justify-center items-center min-h-[60vh]">
          <Loader2 className="h-12 w-12 animate-spin text-gray-500" />
        </div>
      </HeaderWrapper>
    )
  }

  const overallLoading = isCreating

  // Separate selected files by type for preview
  const previewImages = selectedFiles.images.map((file, idx) => ({ id: `image-${idx}`, url: URL.createObjectURL(file), file_type: 'image' }))
  const previewVideos = selectedFiles.videos.map((file, idx) => ({ id: `video-${idx}`, url: URL.createObjectURL(file), file_type: 'video' }))
  const previewModels = selectedFiles.models.map((file, idx) => ({ id: `model-${idx}`, url: URL.createObjectURL(file), file_type: 'model' }))

  return (
    <HeaderWrapper>
      <div className="container mx-auto py-10">
        {/* Product Media Preview */}
        <div className="mb-8 space-y-6">
          {/* Images Preview */}
          {previewImages.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Product Images</h3>
              <ProductGallery media={previewImages} productName={form.watch('name') || "Product"} />
            </div>
          )}

          {/* 3D Models Preview */}
          {previewModels.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <CuboidIcon className="h-4 w-4" />
                3D Models
              </h3>
              <Simple3DViewer
                modelUrl={previewModels[0]?.url}
                productName={form.watch('name') || "Product"}
                isDefault={false}
                width={500}
                height={400}
                showControls={true}
                showARButton={true}
              />
            </div>
          )}

          {/* Videos Preview */}
          {previewVideos.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <Play className="h-4 w-4" />
                Product Videos
              </h3>
              <div className="grid grid-cols-1 gap-2">
                {previewVideos.slice(0, 2).map((video, index) => (
                  <div key={index} className="relative aspect-video overflow-hidden rounded-md border">
                    <video
                      src={video.url}
                      controls
                      className="w-full h-full object-cover"
                      poster="/placeholder.svg?height=200&width=300"
                    >
                      Your browser does not support the video tag.
                    </video>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="max-w-6xl mx-auto">
              <div className="flex justify-between items-center mb-6">
                <Button asChild variant="outline">
                  <Link href="/dashboard?tab=products">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back to Products
                  </Link>
                </Button>
                <h1 className="text-2xl font-bold">Create New Product</h1>
                <Button type="submit" disabled={overallLoading}>
                  {overallLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Create Product
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column */}
                <div className="lg:col-span-2 space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Product Details</CardTitle>
                      <CardDescription>Start with the name, description, and other core details.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Product Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., 'Wooden Chair'" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Describe your product in detail..." rows={6} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* Enhanced Media Management */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Upload className="h-5 w-5" />
                        Media Upload
                      </CardTitle>
                      <CardDescription>
                        Upload images, videos, and 3D models for your product. You can also generate 3D models from images later.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="images" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="images" className="flex items-center gap-2">
                            <Image className="h-4 w-4" />
                            Images ({selectedFiles.images.length})
                          </TabsTrigger>
                          <TabsTrigger value="videos" className="flex items-center gap-2">
                            <Video className="h-4 w-4" />
                            Videos ({selectedFiles.videos.length})
                          </TabsTrigger>
                          <TabsTrigger value="models" className="flex items-center gap-2">
                            <CuboidIcon className="h-4 w-4" />
                            3D Models ({selectedFiles.models.length})
                          </TabsTrigger>
                        </TabsList>

                        <TabsContent value="images" className="space-y-4">
                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                            <FileImage className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                            <p className="text-sm text-gray-600 mb-4">
                              Upload product images (JPG, PNG, WebP). First image will be the main product image.
                            </p>
                            <input
                              type="file"
                              multiple
                              accept="image/*"
                              onChange={(e) => handleFileSelect("images", e.target.files)}
                              className="hidden"
                              id="image-upload"
                              ref={imageInputRef}
                            />
                            <Button
                              variant="outline"
                              className="cursor-pointer"
                              type="button"
                              onClick={() => imageInputRef.current?.click()}
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              Select Images
                            </Button>
                          </div>
                          {selectedFiles.images.length > 0 && (
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                              {selectedFiles.images.map((file, index) => (
                                <div key={index} className="relative group">
                                  <img
                                    src={URL.createObjectURL(file)}
                                    alt={`Preview ${index + 1}`}
                                    className="w-full h-32 object-cover rounded-lg"
                                  />
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="destructive"
                                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => removeFile('images', index)}
                                  >
                                    ×
                                  </Button>
                                  {index === 0 && (
                                    <Badge className="absolute top-2 left-2 bg-blue-500">Main</Badge>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>

                        <TabsContent value="videos" className="space-y-4">
                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                            <FileVideo className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                            <p className="text-sm text-gray-600 mb-4">
                              Upload product videos (MP4, WebM, MOV). Keep files under 50MB for best performance.
                            </p>
                            <input
                              type="file"
                              multiple
                              accept="video/*"
                              onChange={(e) => handleFileSelect("videos", e.target.files)}
                              className="hidden"
                              id="video-upload"
                              ref={videoInputRef}
                            />
                            <Button
                              variant="outline"
                              className="cursor-pointer"
                              type="button"
                              onClick={() => videoInputRef.current?.click()}
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              Select Videos
                            </Button>
                          </div>
                          {selectedFiles.videos.length > 0 && (
                            <div className="space-y-4">
                              {selectedFiles.videos.map((file, index) => (
                                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                  <div className="flex items-center gap-3">
                                    <FileVideo className="h-8 w-8 text-blue-500" />
                                    <div>
                                      <p className="font-medium">{file.name}</p>
                                      <p className="text-sm text-gray-500">
                                        {(file.size / 1024 / 1024).toFixed(2)} MB
                                      </p>
                                    </div>
                                  </div>
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => removeFile('videos', index)}
                                  >
                                    Remove
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>

                        <TabsContent value="models" className="space-y-4">
                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                            <File className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                            <p className="text-sm text-gray-600 mb-4">
                              Upload 3D models (GLB, GLTF, OBJ). Or generate one from images using AI.
                            </p>
                            <div className="flex gap-2 justify-center">
                              <input
                                type="file"
                                multiple
                                accept=".glb,.gltf,.obj,.fbx,.3ds"
                                onChange={(e) => handleFileSelect("models", e.target.files)}
                                className="hidden"
                                id="model-upload"
                                ref={modelInputRef}
                              />
                              <Button
                                variant="outline"
                                className="cursor-pointer"
                                type="button"
                                onClick={() => modelInputRef.current?.click()}
                              >
                                <Upload className="h-4 w-4 mr-2" />
                                Upload 3D Model
                              </Button>
                            </div>
                          </div>
                          {selectedFiles.models.length > 0 && (
                            <div className="space-y-4">
                              {selectedFiles.models.map((file, index) => (
                                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                  <div className="flex items-center gap-3">
                                    <File className="h-8 w-8 text-purple-500" />
                                    <div>
                                      <p className="font-medium">{file.name}</p>
                                      <p className="text-sm text-gray-500">
                                        {(file.size / 1024 / 1024).toFixed(2)} MB
                                      </p>
                                    </div>
                                  </div>
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => removeFile('models', index)}
                                  >
                                    Remove
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>

                  {/* 3D Model Generation Instructions */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CuboidIcon className="h-5 w-5" />
                        Generate 3D Models from Images
                      </CardTitle>
                      <CardDescription>
                        Create stunning 3D models from your product images using AI technology.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Alert>
                        <Info className="h-4 w-4" />
                        <AlertTitle>How to Generate 3D Models</AlertTitle>
                        <AlertDescription>
                          After creating your product, you can generate 3D models from 2D images. Here's what you need:
                        </AlertDescription>
                      </Alert>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <h4 className="font-semibold flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            Required Images
                          </h4>
                          <ul className="space-y-2 text-sm">
                            <li>• <strong>6 angle photos</strong> of your product</li>
                            <li>• <strong>Front view</strong> - straight on</li>
                            <li>• <strong>Back view</strong> - opposite side</li>
                            <li>• <strong>Left side</strong> - 90° from front</li>
                            <li>• <strong>Right side</strong> - 90° from front</li>
                            <li>• <strong>Top view</strong> - looking down</li>
                            <li>• <strong>Bottom view</strong> - looking up</li>
                          </ul>
                        </div>
                        <div className="space-y-3">
                          <h4 className="font-semibold flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-orange-500" />
                            Best Practices
                          </h4>
                          <ul className="space-y-2 text-sm">
                            <li>• Use <strong>high-quality images</strong> (min 1024x1024px)</li>
                            <li>• Ensure <strong>good lighting</strong> and no shadows</li>
                            <li>• Use <strong>plain background</strong> (white/gray)</li>
                            <li>• Keep <strong>consistent camera distance</strong></li>
                            <li>• Avoid <strong>reflections and glare</strong></li>
                            <li>• Product should be <strong>centered</strong> in each image</li>
                          </ul>
                        </div>
                      </div>
                      <Separator />
                      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                        <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                          <Camera className="h-4 w-4 inline mr-2" />
                          Photography Tips
                        </h4>
                        <div className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                          <p>• Use a tripod for consistent positioning</p>
                          <p>• Set your camera to manual mode for consistent exposure</p>
                          <p>• Use natural light or soft artificial lighting</p>
                          <p>• Take photos from the same distance for all angles</p>
                          <p>• Ensure the product takes up 70-80% of the frame</p>
                        </div>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600 mb-2">
                          After creating your product, go to the edit page to generate 3D models
                        </p>
                        <Badge variant="outline" className="text-xs">
                          AI-powered 3D generation takes 5-15 minutes
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Right Column */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Pricing & Inventory</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price ($)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" placeholder="e.g., 99.99" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="discount_price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Discount Price ($) (Optional)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" placeholder="e.g., 79.99" {...field} value={field.value ?? ''} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="stock"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Stock Quantity</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="e.g., 100" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Category</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Product Category</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {categories?.map((cat) => (
                                  <SelectItem key={cat.id} value={String(cat.id)}>
                                    {cat.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>
                  {/* Media Summary */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Media Summary</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <Image className="h-4 w-4" />
                          Images
                        </span>
                        <Badge variant={selectedFiles.images.length > 0 ? "default" : "secondary"}>
                          {selectedFiles.images.length}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <Video className="h-4 w-4" />
                          Videos
                        </span>
                        <Badge variant={selectedFiles.videos.length > 0 ? "default" : "secondary"}>
                          {selectedFiles.videos.length}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <CuboidIcon className="h-4 w-4" />
                          3D Models
                        </span>
                        <Badge variant={selectedFiles.models.length > 0 ? "default" : "secondary"}>
                          {selectedFiles.models.length}
                        </Badge>
                      </div>
                      <Separator />
                      <div className="text-sm text-gray-600">
                        Total files: {selectedFiles.images.length + selectedFiles.videos.length + selectedFiles.models.length}
                      </div>
                    </CardContent>
                  </Card>
                  {/* Additional Info */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Additional Info</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="inactive">Inactive</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="is_active"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                            <div className="space-y-0.5">
                              <FormLabel>Is Active</FormLabel>
                            </div>
                            <FormControl>
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={e => field.onChange(e.target.checked)}
                                className="form-checkbox h-5 w-5 text-blue-600"
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="weight"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Weight (kg)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 1.5" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="length"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Length (cm)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 30" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="width"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Width (cm)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 20" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="height"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Height (cm)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" placeholder="e.g., 10" {...field} value={field.value ?? ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
              <div className="flex justify-end mt-8">
                <Button type="submit" disabled={overallLoading} size="lg">
                  {overallLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Create Product & Continue
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </div>
      <Footer />
    </HeaderWrapper>
  )
}